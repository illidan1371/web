@extends('layouts.dashboard')

@section('name')
    test title
@stop

@section('content')
    <table>
        <thead>
        <td>name</td>
        <td>description</td>
        <td>download</td>
        </thead>
        <tbody>
        @foreach($documents as $document)
            <tr>
                <td>{{$document->name}}</td>
                <td>{{$document->description}}</td>
                <td><a href="{{asset('/documents/'.$document->file_name)}}">دانلود فایل</a></td>
            </tr>
        @endforeach
        </tbody>

    </table>
@stop